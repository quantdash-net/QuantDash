import math
import unittest
import numpy as np
import pandas as pd

from grid_strategy import (
    GridConfig, GridStrategy, recommend_spacing_pct, run_backtest,
    volatility_stats,
)


class TestGrid(unittest.TestCase):
    def test_article_volatility_formula(self):
        close = pd.Series([100, 101, 99, 102, 100, 103, 101, 104, 102, 105,
                           103, 106, 104, 107, 105, 108, 106, 109, 107, 110,
                           108, 111, 109, 112, 110])
        df = pd.DataFrame({
            "open": close, "high": close * 1.01,
            "low": close * 0.99, "close": close
        })
        stats = volatility_stats(df, recent_window=20, annualization=252)
        expected = close.pct_change().rolling(20).std().iloc[-1] * math.sqrt(252)
        self.assertAlmostEqual(stats["latest_recent_vol"], expected, places=12)

    def test_article_spacing_rule(self):
        stats = {"latest_recent_vol": 0.3215}
        self.assertAlmostEqual(recommend_spacing_pct(stats, 9), 0.0357222222, places=9)

    def test_grid_levels(self):
        s = GridStrategy(GridConfig(grid_count_each_side=2))
        s.initialize(100, 0.10)
        self.assertEqual(set(s.levels), {-2, -1, 0, 1, 2})
        self.assertAlmostEqual(s.levels[1], 110)
        self.assertAlmostEqual(s.levels[-1], 100 / 1.1)

    def test_buy_on_downward_cross(self):
        cfg = GridConfig(
            reference_price=100, spacing_pct=0.10,
            grid_count_each_side=2, initial_cash=10_000,
            cash_per_grid=1_000
        )
        s = GridStrategy(cfg)
        s.initialize(100, 0.10)
        trades = s.process_bar("t1", 100, 100, 88, 90)
        buys = [t for t in trades if t.side == "BUY"]
        self.assertTrue(any(t.grid_level == -1 for t in buys))
        # The same OHLC bar subsequently reaches the reference grid, so the
        # newly bought inventory may also be sold under the documented
        # open->low->high->close path assumption.
        self.assertGreaterEqual(len(buys), 1)

    def test_sell_requires_inventory(self):
        cfg = GridConfig(
            reference_price=100, spacing_pct=0.10,
            grid_count_each_side=2, initial_cash=10_000,
            cash_per_grid=1_000
        )
        s = GridStrategy(cfg)
        s.initialize(100, 0.10)
        trades = s.process_bar("t1", 100, 120, 100, 120)
        self.assertFalse(any(t.side == "SELL" for t in trades))
        self.assertEqual(s.position, 0)

    def test_buy_then_sell_one_grid(self):
        cfg = GridConfig(
            reference_price=100, spacing_pct=0.10,
            grid_count_each_side=2, initial_cash=10_000,
            cash_per_grid=1_000
        )
        s = GridStrategy(cfg)
        s.initialize(100, 0.10)
        first_bar = s.process_bar("t1", 100, 100, 89, 90)
        buys = [t for t in first_bar if t.side == "BUY"]
        sells = [t for t in first_bar if t.side == "SELL"]
        self.assertTrue(any(t.grid_level == -1 for t in buys))
        self.assertTrue(any(t.grid_level == 0 for t in sells))
        self.assertEqual(s.position, 0)

    def test_cash_constraint(self):
        cfg = GridConfig(
            reference_price=100, spacing_pct=0.10,
            grid_count_each_side=2, initial_cash=50,
            cash_per_grid=1_000
        )
        s = GridStrategy(cfg)
        s.initialize(100, 0.10)
        trades = s.process_bar("t1", 100, 100, 80, 80)
        self.assertEqual(len(trades), 0)
        self.assertEqual(s.position, 0)

    def test_lot_size(self):
        cfg = GridConfig(
            reference_price=100, spacing_pct=0.10,
            grid_count_each_side=1, initial_cash=10_000,
            cash_per_grid=1_050, lot_size=100
        )
        s = GridStrategy(cfg)
        s.initialize(100, 0.10)
        s.process_bar("t1", 100, 100, 89, 90)
        self.assertEqual(s.position % 100, 0)

    def test_fee_and_slippage(self):
        cfg = GridConfig(
            reference_price=100, spacing_pct=0.10,
            grid_count_each_side=1, initial_cash=10_000,
            cash_per_grid=1_000, commission_rate=0.001,
            stamp_duty_rate=0.001, slippage_rate=0.001
        )
        s = GridStrategy(cfg)
        s.initialize(100, 0.10)
        first_bar = s.process_bar("t1", 100, 100, 89, 90)
        buys = [t for t in first_bar if t.side == "BUY"]
        sells = [t for t in first_bar if t.side == "SELL"]
        self.assertTrue(buys)
        self.assertTrue(sells)
        self.assertLess(buys[0].cash_after, 10_000)
        self.assertTrue(any(t.stamp_duty > 0 for t in sells))

    def test_backtest_is_deterministic(self):
        idx = pd.date_range("2026-01-01", periods=30, freq="D")
        close = 100 + 5 * np.sin(np.arange(30) / 2)
        df = pd.DataFrame({
            "open": close,
            "high": close + 1,
            "low": close - 1,
            "close": close,
        }, index=idx)
        cfg = GridConfig(
            grid_count_each_side=3,
            initial_cash=10_000,
            cash_per_grid=500,
        )
        r1 = run_backtest(df, cfg)
        r2 = run_backtest(df, cfg)
        self.assertEqual(r1["trade_count"], r2["trade_count"])
        self.assertAlmostEqual(r1["final_equity"], r2["final_equity"], places=10)

    def test_invalid_data(self):
        df = pd.DataFrame({
            "open": [1], "high": [0.5], "low": [1], "close": [1]
        })
        with self.assertRaises(ValueError):
            run_backtest(df, GridConfig())


if __name__ == "__main__":
    unittest.main()
