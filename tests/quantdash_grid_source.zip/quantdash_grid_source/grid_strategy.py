from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Optional
import math
import numpy as np
import pandas as pd


@dataclass(frozen=True)
class GridConfig:
    """Grid parameters.

    The article explicitly defines volatility-driven spacing, but does not define
    capital allocation, grid count, fees, lot size, or range. Those are therefore
    explicit engineering parameters rather than claims about the article.
    """
    reference_price: Optional[float] = None
    spacing_pct: Optional[float] = None
    grid_count_each_side: int = 10
    initial_cash: float = 100_000.0
    initial_position: float = 0.0
    cash_per_grid: Optional[float] = None
    commission_rate: float = 0.0
    stamp_duty_rate: float = 0.0  # normally applied only to sells for CN stocks
    slippage_rate: float = 0.0
    lot_size: float = 1.0
    annualization: int = 252
    recent_vol_window: int = 20
    spacing_divisor: float = 9.0


@dataclass
class Trade:
    timestamp: object
    side: str
    price: float
    quantity: float
    grid_level: int
    commission: float
    stamp_duty: float
    cash_after: float
    position_after: float


def validate_ohlcv(df: pd.DataFrame) -> None:
    required = {"open", "high", "low", "close"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing OHLC columns: {sorted(missing)}")
    if df.empty:
        raise ValueError("OHLCV data is empty")
    if df[["open", "high", "low", "close"]].isna().any().any():
        raise ValueError("OHLC data contains NaN values")
    if (df["high"] < df["low"]).any():
        raise ValueError("Found high < low")
    if (df[["open", "high", "low", "close"]] <= 0).any().any():
        raise ValueError("Prices must be positive")


def volatility_stats(df: pd.DataFrame, recent_window: int = 20,
                     annualization: int = 252) -> Dict[str, float]:
    """Replicates the article's volatility calculation."""
    validate_ohlcv(df)
    if recent_window < 2:
        raise ValueError("recent_window must be >= 2")
    returns = df["close"].pct_change()
    annual_vol = returns.std() * math.sqrt(annualization)
    latest_vol = returns.rolling(recent_window).std().iloc[-1] * math.sqrt(annualization)
    return {
        "annual_vol": float(annual_vol),
        "latest_recent_vol": float(latest_vol),
        "max_return": float(returns.max()),
        "min_return": float(returns.min()),
        "avg_return": float(returns.mean()),
        "close_current": float(df["close"].iloc[-1]),
        "close_first": float(df["close"].iloc[0]),
    }


def recommend_spacing_pct(stats: Dict[str, float], divisor: float = 9.0) -> float:
    """Article-aligned baseline: recent annualized volatility / divisor.

    The article's worked example uses 32.15% / 9 ~= 3.57% and recommends 3.5%.
    The prose mentions 7~8 but the concrete calculation uses 9; we expose the
    divisor so this inconsistency is not hidden.
    """
    if divisor <= 0:
        raise ValueError("divisor must be positive")
    vol = stats["latest_recent_vol"]
    if not np.isfinite(vol) or vol <= 0:
        raise ValueError("Recent volatility is unavailable or non-positive")
    return float(vol / divisor)


class GridStrategy:
    """Long-only arithmetic grid.

    A completed buy at grid i creates inventory that is sold at grid i+1.
    A completed sell at grid i creates a re-entry buy at grid i-1.

    This execution rule is an implementation choice because the article describes
    step-size recommendation, not a full order-state specification.
    """

    def __init__(self, config: GridConfig):
        if config.grid_count_each_side < 1:
            raise ValueError("grid_count_each_side must be >= 1")
        if config.initial_cash < 0 or config.initial_position < 0:
            raise ValueError("Initial cash/position cannot be negative")
        if config.lot_size <= 0:
            raise ValueError("lot_size must be positive")
        self.cfg = config
        self.reference_price: Optional[float] = None
        self.spacing_pct: Optional[float] = None
        self.levels: Dict[int, float] = {}
        self.cash = float(config.initial_cash)
        self.position = float(config.initial_position)
        self.trades: List[Trade] = []
        self._inventory_by_buy_level: Dict[int, float] = {}

    def initialize(self, reference_price: float, spacing_pct: float) -> None:
        if reference_price <= 0:
            raise ValueError("reference_price must be positive")
        if spacing_pct <= 0:
            raise ValueError("spacing_pct must be positive")
        self.reference_price = float(reference_price)
        self.spacing_pct = float(spacing_pct)
        n = self.cfg.grid_count_each_side
        self.levels = {
            i: self.reference_price * ((1 + self.spacing_pct) ** i)
            for i in range(-n, n + 1)
        }

    def initialize_from_history(self, df: pd.DataFrame) -> Dict[str, float]:
        stats = volatility_stats(
            df, recent_window=self.cfg.recent_vol_window,
            annualization=self.cfg.annualization
        )
        ref = self.cfg.reference_price or stats["close_current"]
        spacing = self.cfg.spacing_pct or recommend_spacing_pct(
            stats, self.cfg.spacing_divisor
        )
        self.initialize(ref, spacing)
        return stats

    def _buy_price(self, level_price: float) -> float:
        return level_price * (1 + self.cfg.slippage_rate)

    def _sell_price(self, level_price: float) -> float:
        return level_price * (1 - self.cfg.slippage_rate)

    def _round_qty(self, qty: float) -> float:
        if qty <= 0:
            return 0.0
        units = math.floor((qty + 1e-12) / self.cfg.lot_size)
        return units * self.cfg.lot_size

    def _grid_quantity(self, price: float) -> float:
        budget = self.cfg.cash_per_grid
        if budget is None:
            # Explicit, deterministic fallback: equal cash allocation across
            # all grid levels below the reference price.
            n_buy_levels = self.cfg.grid_count_each_side
            budget = self.cfg.initial_cash / max(n_buy_levels, 1)
        return self._round_qty(budget / price)

    def _execute_buy(self, timestamp, level: int) -> Optional[Trade]:
        raw_price = self.levels[level]
        price = self._buy_price(raw_price)
        qty = self._grid_quantity(price)
        if qty <= 0:
            return None
        commission = price * qty * self.cfg.commission_rate
        total = price * qty + commission
        if total > self.cash + 1e-9:
            return None
        self.cash -= total
        self.position += qty
        self._inventory_by_buy_level[level] = (
            self._inventory_by_buy_level.get(level, 0.0) + qty
        )
        t = Trade(timestamp, "BUY", price, qty, level, commission, 0.0,
                  self.cash, self.position)
        self.trades.append(t)
        return t

    def _execute_sell(self, timestamp, level: int) -> Optional[Trade]:
        # Sell inventory bought at the immediately lower grid. This prevents
        # the backtest from creating stock from nothing.
        source_level = level - 1
        available = self._inventory_by_buy_level.get(source_level, 0.0)
        qty = self._round_qty(available)
        if qty <= 0 or self.position < qty - 1e-9:
            return None
        raw_price = self.levels[level]
        price = self._sell_price(raw_price)
        gross = price * qty
        commission = gross * self.cfg.commission_rate
        stamp = gross * self.cfg.stamp_duty_rate
        self.cash += gross - commission - stamp
        self.position -= qty
        self._inventory_by_buy_level[source_level] = available - qty
        t = Trade(timestamp, "SELL", price, qty, level, commission, stamp,
                  self.cash, self.position)
        self.trades.append(t)
        return t

    def process_bar(self, timestamp, open_: float, high: float,
                    low: float, close: float) -> List[Trade]:
        if not self.levels:
            raise RuntimeError("Call initialize() before process_bar()")
        if high < low or min(open_, high, low, close) <= 0:
            raise ValueError("Invalid OHLC bar")

        # OHLC does not reveal the true intrabar path. For deterministic testing,
        # use open -> low -> high -> close. This is an explicit backtest assumption.
        events = []
        prev = open_
        for target_side, endpoint in (("down", low), ("up", high), ("close", close)):
            if endpoint < prev:
                crossed = [
                    (lvl, p) for lvl, p in self.levels.items()
                    if target_side == "down" and prev > p >= endpoint
                ]
                for lvl, _ in sorted(crossed, key=lambda x: x[1], reverse=True):
                    tr = self._execute_buy(timestamp, lvl)
                    if tr:
                        events.append(tr)
            elif endpoint > prev:
                crossed = [
                    (lvl, p) for lvl, p in self.levels.items()
                    if target_side in ("up", "close") and prev < p <= endpoint
                ]
                for lvl, _ in sorted(crossed, key=lambda x: x[1]):
                    tr = self._execute_sell(timestamp, lvl)
                    if tr:
                        events.append(tr)
            prev = endpoint
        return events

    def equity(self, mark_price: float) -> float:
        return self.cash + self.position * mark_price

    def result(self, mark_price: float) -> Dict[str, object]:
        equity = self.equity(mark_price)
        initial_equity = self.cfg.initial_cash + self.cfg.initial_position * (
            self.reference_price or mark_price
        )
        total_return = equity / initial_equity - 1 if initial_equity else math.nan
        return {
            "initial_equity": initial_equity,
            "final_equity": equity,
            "total_return": total_return,
            "cash": self.cash,
            "position": self.position,
            "trade_count": len(self.trades),
            "trades": pd.DataFrame([t.__dict__ for t in self.trades]),
        }


def run_backtest(df: pd.DataFrame, config: GridConfig) -> Dict[str, object]:
    validate_ohlcv(df)
    strategy = GridStrategy(config)
    stats = strategy.initialize_from_history(df)

    equity_curve = []
    for idx, row in df.iterrows():
        strategy.process_bar(
            idx, float(row["open"]), float(row["high"]),
            float(row["low"]), float(row["close"])
        )
        equity_curve.append({
            "timestamp": idx,
            "equity": strategy.equity(float(row["close"])),
            "cash": strategy.cash,
            "position": strategy.position,
            "close": float(row["close"]),
        })

    curve = pd.DataFrame(equity_curve).set_index("timestamp")
    peak = curve["equity"].cummax()
    drawdown = curve["equity"] / peak - 1.0
    result = strategy.result(float(df["close"].iloc[-1]))
    result.update({
        "volatility_stats": stats,
        "spacing_pct": strategy.spacing_pct,
        "reference_price": strategy.reference_price,
        "equity_curve": curve,
        "max_drawdown": float(drawdown.min()),
    })
    return result


def fetch_quantdash_klines(symbol: str, count: int = 60,
                           period: str = "1d", adjust: str = "forward") -> pd.DataFrame:
    """Official-API-shaped QuantDash adapter.

    Per the official Python quickstart:
        from quantdash import QuantDash
        qd = QuantDash()
        qd.klines.get(symbol, period=..., count=..., adjust=..., to_dataframe=True)

    API key is read from QUANTDASH_API_KEY when omitted.
    """
    from quantdash import QuantDash

    qd = QuantDash()
    return qd.klines.get(
        symbol,
        period=period,
        count=count,
        adjust=adjust,
        to_dataframe=True,
    )
