import os
from grid_strategy import GridConfig, run_backtest, fetch_quantdash_klines

# Set QUANTDASH_API_KEY in the environment first.
# Windows PowerShell:
#   $env:QUANTDASH_API_KEY = "your_api_key"
# macOS/Linux:
#   export QUANTDASH_API_KEY="your_api_key"

symbol = "600519.SH"

df = fetch_quantdash_klines(
    symbol=symbol,
    period="1d",
    count=60,
    adjust="forward",
)

cfg = GridConfig(
    grid_count_each_side=10,
    initial_cash=100_000,
    initial_position=0,
    # Article-aligned: recent annualized volatility / 9.
    # Set spacing_pct explicitly to override AI/volatility recommendation.
    spacing_pct=None,
    spacing_divisor=9.0,
    commission_rate=0.0,       # article does not specify fees
    stamp_duty_rate=0.0,
    slippage_rate=0.0,
    lot_size=1.0,               # set 100 for A-share lot simulation if desired
)

result = run_backtest(df, cfg)

print(f"标的: {symbol}")
print(f"参考价: {result['reference_price']:.4f}")
print(f"推荐/使用网格步长: {result['spacing_pct']:.2%}")
print(f"60日年化波动率: {result['volatility_stats']['annual_vol']:.2%}")
print(f"近20日年化波动率: {result['volatility_stats']['latest_recent_vol']:.2%}")
print(f"最终权益: {result['final_equity']:.2f}")
print(f"总收益: {result['total_return']:.2%}")
print(f"最大回撤: {result['max_drawdown']:.2%}")
print(f"成交次数: {result['trade_count']}")
print(result["trades"].to_string(index=False))
