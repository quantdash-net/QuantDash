# QuantDash + 波动率驱动网格交易

这份源码以文章《DeepSeek+QuantDash：3行代码搞定网格交易波动率定步长》的明确公式为核心：

1. 用收盘价计算日收益率；
2. 年化波动率 = 日收益率标准差 × √252；
3. 计算近 20 日滚动年化波动率；
4. 文章的具体示例用“近20日年化波动率 ÷ 9”得到网格步长参考值；
5. 将这个步长用于一个可回测的长仓网格执行器。

## 重要边界

文章主要讲的是“波动率驱动的网格步长智能推荐”，并没有完整规定：
- 网格上下边界；
- 网格层数；
- 每格投入多少资金；
- 初始持仓；
- 手续费、印花税、滑点；
- OHLC 单根K线内多个网格同时穿越时的真实成交顺序。

因此上述项目把这些内容全部做成显式配置，而不是冒充“文章原文规则”。

另外，文章文字写到“波动率 ÷ (7~8)”，但其实际算例使用的是“32.15% ÷ 9 ≈ 3.57%”，并最终建议 3.5%。源码默认跟随这个**具体算例**使用 divisor=9，同时允许修改。

## QuantDash 接口

按照官方 Python SDK 文档：
- `pip install quantdash`
- `from quantdash import QuantDash`
- `qd = QuantDash()` 自动读取 `QUANTDASH_API_KEY`
- `qd.klines.get(symbol, period="1d", count=60, adjust="forward", to_dataframe=True)`

源码没有自行拼接 QuantDash HTTP API，也没有虚构 SDK 方法。

## 安装

```bash
python -m pip install -r requirements.txt
```

配置 API Key：

PowerShell:
```powershell
$env:QUANTDASH_API_KEY="your_api_key"
```

macOS/Linux:
```bash
export QUANTDASH_API_KEY="your_api_key"
```

## 运行真实 QuantDash 回测

```bash
python example_quantdash.py
```

示例默认使用：
```text
600519.SH
60根日K
前复权
```

## 自测

核心策略测试不需要 QuantDash API Key：

```bash
python -m unittest discover -s tests -v
```

测试覆盖：
- 文章波动率公式；
- 文章步长公式；
- 网格生成；
- 下穿买入；
- 无库存不得卖出；
- 买入后上穿卖出；
- 现金约束；
- A股 lot size 约束；
- 手续费/印花税/滑点；
- 回测确定性；
- 异常数据校验。

## 关于回测成交假设

日K的 OHLC 无法告诉我们价格在一根K线内部究竟先到 High 还是 Low。

为了让测试和回测结果确定，代码采用：
`Open -> Low -> High -> Close`

这是**回测工程假设**，不是 QuantDash 数据接口的事实，也不是文章原文规则。

如果要做更接近实盘的网格回测，应使用 QuantDash 的分钟K线，例如 `5m` 或 `1m`，减少单根K线内路径不确定性。
